﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        double Result, N1 , N2 ;
        
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Result = N1 + N2 ;
            txtResult.Text = Result.ToString();
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            Result = N1 - N2 ;
            txtResult.Text = Result.ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            Result = N1 * N2;
            txtResult.Text = Result.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if(N2 == 0) 
            {
                MessageBox.Show("numero nao pode ser dividido por 0.");
                txtN2.Focus();
            }
            else
                 Result = N1 / N2;
                 txtResult.Text = Result.ToString();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtN1.Clear();
            txtN2.Clear();
            txtResult.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtN2_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtN2.Text, out N2))
            {
                MessageBox.Show("numero invalido");
                txtN2.Focus();
            }
        }

        private void txtN1_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtN1.Text, out N1)) 
            {
                MessageBox.Show("numero invalido");
                txtN1.Focus();
            }
        }
    }
}
