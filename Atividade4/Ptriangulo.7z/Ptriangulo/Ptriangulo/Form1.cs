﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        double VA, VB, VC;
        
        
        public Form1()
        {
            InitializeComponent();
        }

        private void txtB_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtB.Text, out VB))
            {
                MessageBox.Show("valor invalido");
                txtB.Focus();
            }
            else if (VB <= 0)
            {
                MessageBox.Show("Valor invalido");
                txtB.Focus();
            }
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            if ((VA < VB + VC) && (VA > Math.Abs(VB - VC) && VB > Math.Abs(VA - VB)))
            {
                if (VA == VB && VB == VC)
                {
                    MessageBox.Show("Triângulo equilátero");
                }
                else if (VA == VB || VB == VC || VA == VC)
                {
                    MessageBox.Show("Triângulo isósceles");
                }
                else
                    MessageBox.Show("Triângulo escaleno");
            }
            else
                MessageBox.Show("Os valores nao formam um triângulo");
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtC_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtC.Text, out VC))
            {
                MessageBox.Show("valor invalido");
                txtC.Focus();
            }
            else if (VC <= 0)
            {
                MessageBox.Show("Valor invalido");
                txtC.Focus();
            }
        }

        private void txtA_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtA.Text, out VA))
            {
                MessageBox.Show("valor invalido");
                txtA.Focus();
            }
            else if (VA <= 0)
            {
                MessageBox.Show("Valor invalido");
                txtA.Focus();
            }
        }
    }
}
