﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTestmetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void lblP1_Click(object sender, EventArgs e)
        {

        }

        private void btnIguais_Click(object sender, EventArgs e)
        {
            if(string.Compare(txtP1.Text, txtP2.Text) == 0)
            {
                MessageBox.Show("Os textos são iguais.");
            }
            else
                MessageBox.Show("Os textos não são iguais.");
        }

        private void btnIns_Click(object sender, EventArgs e)
        {
            string texto = txtP2.Text;
            int metade = texto.Length / 2;

            texto = txtP2.Text.Substring(0, metade) + txtP1.Text + txtP2.Text.Substring(metade);

            txtP2.Text = texto; 
        }
        private void btnIns2_Click(object sender, EventArgs e)
        {
            string nova = txtP1.Text;
            int metade = nova.Length / 2;
            
            
            nova = nova.Insert(metade, "**");
            txtP2.Text = nova;
            
        }
    }
}
