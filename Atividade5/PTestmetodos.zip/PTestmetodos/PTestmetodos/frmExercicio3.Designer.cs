﻿namespace PTestmetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnInvert = new System.Windows.Forms.Button();
            this.btnRem = new System.Windows.Forms.Button();
            this.lblP1 = new System.Windows.Forms.Label();
            this.lblP2 = new System.Windows.Forms.Label();
            this.txtP2 = new System.Windows.Forms.TextBox();
            this.txtP1 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnInvert
            // 
            this.btnInvert.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.btnInvert.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnInvert.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInvert.Location = new System.Drawing.Point(346, 314);
            this.btnInvert.Name = "btnInvert";
            this.btnInvert.Size = new System.Drawing.Size(131, 62);
            this.btnInvert.TabIndex = 14;
            this.btnInvert.Text = "Inverter Texto";
            this.btnInvert.UseVisualStyleBackColor = false;
            this.btnInvert.Click += new System.EventHandler(this.btnInvert_Click);
            // 
            // btnRem
            // 
            this.btnRem.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.btnRem.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRem.Location = new System.Drawing.Point(183, 314);
            this.btnRem.Name = "btnRem";
            this.btnRem.Size = new System.Drawing.Size(131, 62);
            this.btnRem.TabIndex = 13;
            this.btnRem.Text = "Remover Ocorrências do 1 no 2";
            this.btnRem.UseVisualStyleBackColor = false;
            this.btnRem.Click += new System.EventHandler(this.btnRem_Click);
            // 
            // lblP1
            // 
            this.lblP1.AutoSize = true;
            this.lblP1.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.lblP1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP1.Location = new System.Drawing.Point(116, 96);
            this.lblP1.Name = "lblP1";
            this.lblP1.Size = new System.Drawing.Size(103, 25);
            this.lblP1.TabIndex = 12;
            this.lblP1.Text = "Palavra 1";
            // 
            // lblP2
            // 
            this.lblP2.AutoSize = true;
            this.lblP2.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.lblP2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblP2.Location = new System.Drawing.Point(116, 187);
            this.lblP2.Name = "lblP2";
            this.lblP2.Size = new System.Drawing.Size(109, 25);
            this.lblP2.TabIndex = 11;
            this.lblP2.Text = "Palavra 2 ";
            // 
            // txtP2
            // 
            this.txtP2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtP2.Location = new System.Drawing.Point(257, 187);
            this.txtP2.Name = "txtP2";
            this.txtP2.Size = new System.Drawing.Size(220, 29);
            this.txtP2.TabIndex = 10;
            // 
            // txtP1
            // 
            this.txtP1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtP1.Location = new System.Drawing.Point(257, 93);
            this.txtP1.Name = "txtP1";
            this.txtP1.Size = new System.Drawing.Size(220, 29);
            this.txtP1.TabIndex = 9;
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PTestmetodos.Properties.Resources.Capturar;
            this.ClientSize = new System.Drawing.Size(537, 463);
            this.Controls.Add(this.btnInvert);
            this.Controls.Add(this.btnRem);
            this.Controls.Add(this.lblP1);
            this.Controls.Add(this.lblP2);
            this.Controls.Add(this.txtP2);
            this.Controls.Add(this.txtP1);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnInvert;
        private System.Windows.Forms.Button btnRem;
        private System.Windows.Forms.Label lblP1;
        private System.Windows.Forms.Label lblP2;
        private System.Windows.Forms.TextBox txtP2;
        private System.Windows.Forms.TextBox txtP1;
    }
}