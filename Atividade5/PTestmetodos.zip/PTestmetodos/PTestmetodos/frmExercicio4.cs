﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTestmetodos
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContN_Click(object sender, EventArgs e)
        {
            int tam = rchtxtFrase.Text.Length;
            int ContN = 0;
            int i = 0;
            while (i < tam) 
            {
                if (char.IsNumber(rchtxtFrase.Text[i]))
                {
                    ContN++;
                    
                }
                i++;
            }
            MessageBox.Show($"Quantidade de números: {ContN}");
        }

        private void btnEspBranco_Click(object sender, EventArgs e)
        {
            int posicao = -1;
            for (var i=0; i< rchtxtFrase.Text.Length; i++) 
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i+1;
                    break; 
                }
            }
            if(posicao == -1)
            {
                MessageBox.Show("não existe espaço em branco");
            }
            else
                MessageBox.Show($"Posição 1 caracter branco: {posicao}");
        
        }

        private void btnContLetra_Click(object sender, EventArgs e)
        {
            int tam = rchtxtFrase.Text.Length;
            int ContL= 0;

            foreach (char c in rchtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    ContL++;

                }
            }
            MessageBox.Show($"Quantidade de Letras: {ContL}");
        }

        private void rchtxtFrase_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
