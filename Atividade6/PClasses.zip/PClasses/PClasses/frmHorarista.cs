﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PClasses
{
    public partial class frmHorarista : Form
    {
        public frmHorarista()
        {
            InitializeComponent();
        }

        private void btnIH_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMA.Text);
            objHorista.SalarioHora = Convert.ToDouble(txtSH.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtNH.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(txtData.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtDF.Text);

            MessageBox.Show("Nome: " + objHorista.NomeEmpregado +
                "\n" + "Matricula: " + objHorista.Matricula  +
                "\n" + "Tempo Trabalho: " + objHorista.TempoTrabalho() + 
                "\n" + "Salario: " + objHorista.SalarioBruto().ToString("N2"));
        }
    }
}
