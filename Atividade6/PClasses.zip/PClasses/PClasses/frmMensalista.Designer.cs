﻿namespace PClasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMA = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSM = new System.Windows.Forms.TextBox();
            this.txtData = new System.Windows.Forms.TextBox();
            this.lblMa = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSM = new System.Windows.Forms.Label();
            this.lblData = new System.Windows.Forms.Label();
            this.btnIM = new System.Windows.Forms.Button();
            this.btnINP = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtMA
            // 
            this.txtMA.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMA.Location = new System.Drawing.Point(338, 109);
            this.txtMA.Name = "txtMA";
            this.txtMA.Size = new System.Drawing.Size(90, 26);
            this.txtMA.TabIndex = 0;
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(338, 135);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(260, 26);
            this.txtNome.TabIndex = 1;
            // 
            // txtSM
            // 
            this.txtSM.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSM.Location = new System.Drawing.Point(338, 161);
            this.txtSM.Name = "txtSM";
            this.txtSM.Size = new System.Drawing.Size(207, 26);
            this.txtSM.TabIndex = 2;
            // 
            // txtData
            // 
            this.txtData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtData.Location = new System.Drawing.Point(338, 187);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(207, 26);
            this.txtData.TabIndex = 3;
            // 
            // lblMa
            // 
            this.lblMa.AutoSize = true;
            this.lblMa.BackColor = System.Drawing.Color.Tomato;
            this.lblMa.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblMa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMa.Location = new System.Drawing.Point(74, 112);
            this.lblMa.Name = "lblMa";
            this.lblMa.Size = new System.Drawing.Size(73, 20);
            this.lblMa.TabIndex = 4;
            this.lblMa.Text = "Matricula";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.BackColor = System.Drawing.Color.Tomato;
            this.lblNome.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(72, 141);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(51, 20);
            this.lblNome.TabIndex = 5;
            this.lblNome.Text = "Nome";
            // 
            // lblSM
            // 
            this.lblSM.AutoSize = true;
            this.lblSM.BackColor = System.Drawing.Color.Tomato;
            this.lblSM.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblSM.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSM.Location = new System.Drawing.Point(72, 167);
            this.lblSM.Name = "lblSM";
            this.lblSM.Size = new System.Drawing.Size(113, 20);
            this.lblSM.TabIndex = 6;
            this.lblSM.Text = "Salário Mensal";
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.BackColor = System.Drawing.Color.Tomato;
            this.lblData.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.lblData.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblData.Location = new System.Drawing.Point(72, 193);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(219, 20);
            this.lblData.TabIndex = 7;
            this.lblData.Text = "Data de Entrada Na Empresa";
            // 
            // btnIM
            // 
            this.btnIM.BackColor = System.Drawing.Color.Tomato;
            this.btnIM.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnIM.Location = new System.Drawing.Point(140, 299);
            this.btnIM.Name = "btnIM";
            this.btnIM.Size = new System.Drawing.Size(175, 55);
            this.btnIM.TabIndex = 8;
            this.btnIM.Text = "Instanciar Mensalista";
            this.btnIM.UseVisualStyleBackColor = false;
            this.btnIM.Click += new System.EventHandler(this.btnIM_Click);
            // 
            // btnINP
            // 
            this.btnINP.BackColor = System.Drawing.Color.Tomato;
            this.btnINP.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnINP.Location = new System.Drawing.Point(338, 299);
            this.btnINP.Name = "btnINP";
            this.btnINP.Size = new System.Drawing.Size(175, 55);
            this.btnINP.TabIndex = 9;
            this.btnINP.Text = "Intancial Mensalista passando parâmetro";
            this.btnINP.UseVisualStyleBackColor = false;
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PClasses.Properties.Resources.Capturar;
            this.ClientSize = new System.Drawing.Size(626, 450);
            this.Controls.Add(this.btnINP);
            this.Controls.Add(this.btnIM);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.lblSM);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMa);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtSM);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMA);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.Load += new System.EventHandler(this.frmMensalista_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMA;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSM;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.Label lblMa;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSM;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.Button btnIM;
        private System.Windows.Forms.Button btnINP;
    }
}