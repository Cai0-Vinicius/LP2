﻿namespace PAtividade7
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnEsp = new System.Windows.Forms.Button();
            this.btnLR = new System.Windows.Forms.Button();
            this.btnPar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.rchtxtFrase.Location = new System.Drawing.Point(21, 78);
            this.rchtxtFrase.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(559, 286);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnEsp
            // 
            this.btnEsp.BackColor = System.Drawing.Color.Chocolate;
            this.btnEsp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEsp.Location = new System.Drawing.Point(675, 78);
            this.btnEsp.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnEsp.Name = "btnEsp";
            this.btnEsp.Size = new System.Drawing.Size(132, 59);
            this.btnEsp.TabIndex = 1;
            this.btnEsp.Text = "Quantidade de espaço em branco";
            this.btnEsp.UseVisualStyleBackColor = false;
            this.btnEsp.Click += new System.EventHandler(this.btnFor_Click);
            // 
            // btnLR
            // 
            this.btnLR.BackColor = System.Drawing.Color.Chocolate;
            this.btnLR.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnLR.Location = new System.Drawing.Point(675, 191);
            this.btnLR.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnLR.Name = "btnLR";
            this.btnLR.Size = new System.Drawing.Size(132, 59);
            this.btnLR.TabIndex = 2;
            this.btnLR.Text = "Letras R";
            this.btnLR.UseVisualStyleBackColor = false;
            this.btnLR.Click += new System.EventHandler(this.btnLR_Click);
            // 
            // btnPar
            // 
            this.btnPar.BackColor = System.Drawing.Color.Chocolate;
            this.btnPar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPar.Location = new System.Drawing.Point(675, 303);
            this.btnPar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPar.Name = "btnPar";
            this.btnPar.Size = new System.Drawing.Size(132, 59);
            this.btnPar.TabIndex = 3;
            this.btnPar.Text = "Par de letras";
            this.btnPar.UseVisualStyleBackColor = false;
            this.btnPar.Click += new System.EventHandler(this.btnPar_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PAtividade7.Properties.Resources.Capturar;
            this.ClientSize = new System.Drawing.Size(862, 454);
            this.Controls.Add(this.btnPar);
            this.Controls.Add(this.btnLR);
            this.Controls.Add(this.btnEsp);
            this.Controls.Add(this.rchtxtFrase);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnEsp;
        private System.Windows.Forms.Button btnLR;
        private System.Windows.Forms.Button btnPar;
    }
}