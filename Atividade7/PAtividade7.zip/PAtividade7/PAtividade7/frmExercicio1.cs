﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmExercicio1 : Form
    {
        public frmExercicio1()
        {
            InitializeComponent();
        }

        private void btnLR_Click(object sender, EventArgs e)
        {
            int tam = rchtxtFrase.Text.Length;
            int ContN = 0;
            int i = 0;
           
            while (i < tam)
            {
                if (rchtxtFrase.Text[i] == 'r' || rchtxtFrase.Text[i] == 'R')
                {
                    ContN++;
                }
                i++;
            }
            MessageBox.Show($"Quantidade de Letras R: {ContN}");
        }

        private void btnFor_Click(object sender, EventArgs e)
        {
            int ConT_Espaço = 0;
            

            foreach (char i in rchtxtFrase.Text)
            {
                if (Char.IsWhiteSpace(i))
                {
                    ConT_Espaço++;
                }
            }
            MessageBox.Show($"Quantidade de Espaços: {ConT_Espaço}");
        }

        private void btnPar_Click(object sender, EventArgs e)
        {
            int tam = rchtxtFrase.Text.Length;
            int Cont_rep = 0;
            int i = 0;

            for (i = 1; i < tam; i++)
            { 
                if (rchtxtFrase.Text[i] == rchtxtFrase.Text[i-1])
                {
                    Cont_rep++;
                }
            }
            MessageBox.Show($"Quantidade de Par de letras: {Cont_rep}");
        }
    }
}
