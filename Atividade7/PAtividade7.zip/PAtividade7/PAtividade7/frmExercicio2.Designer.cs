﻿namespace PAtividade7
{
    partial class frmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtN = new System.Windows.Forms.TextBox();
            this.lblN = new System.Windows.Forms.Label();
            this.btnH = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtN
            // 
            this.txtN.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtN.Location = new System.Drawing.Point(300, 153);
            this.txtN.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtN.Name = "txtN";
            this.txtN.Size = new System.Drawing.Size(311, 32);
            this.txtN.TabIndex = 0;
            this.txtN.Validating += new System.ComponentModel.CancelEventHandler(this.txtN_Validating);
            // 
            // lblN
            // 
            this.lblN.AutoSize = true;
            this.lblN.BackColor = System.Drawing.Color.Chocolate;
            this.lblN.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblN.Location = new System.Drawing.Point(53, 161);
            this.lblN.Name = "lblN";
            this.lblN.Size = new System.Drawing.Size(168, 24);
            this.lblN.TabIndex = 1;
            this.lblN.Text = "Indique o Numero:";
            this.lblN.Click += new System.EventHandler(this.lblN_Click);
            // 
            // btnH
            // 
            this.btnH.BackColor = System.Drawing.Color.Chocolate;
            this.btnH.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnH.Location = new System.Drawing.Point(300, 296);
            this.btnH.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnH.Name = "btnH";
            this.btnH.Size = new System.Drawing.Size(311, 70);
            this.btnH.TabIndex = 2;
            this.btnH.Text = "Numero H";
            this.btnH.UseVisualStyleBackColor = false;
            this.btnH.Click += new System.EventHandler(this.btnH_Click);
            // 
            // frmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PAtividade7.Properties.Resources.Capturar;
            this.ClientSize = new System.Drawing.Size(781, 466);
            this.Controls.Add(this.btnH);
            this.Controls.Add(this.lblN);
            this.Controls.Add(this.txtN);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "frmExercicio2";
            this.Text = "frmExercicio2";
            this.Load += new System.EventHandler(this.frmExercicio2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtN;
        private System.Windows.Forms.Label lblN;
        private System.Windows.Forms.Button btnH;
    }
}