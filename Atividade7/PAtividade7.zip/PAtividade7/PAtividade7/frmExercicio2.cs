﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmExercicio2 : Form
    {
        int N;
        double H;
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void txtN_Validating(object sender, CancelEventArgs e)
        {
            if(!int.TryParse(txtN.Text, out N))
            {
                MessageBox.Show("Somente numero permitido.");
                txtN.Focus();
            }
            else if(N <= 0) 
            {
                MessageBox.Show("Apenas Numero acima de 0.");
                txtN.Focus();
            }
        }

        private void btnH_Click(object sender, EventArgs e)
        {
           
            // H = 0;
            for (double i = 1; i <= N; i++)
            {
                H += 1 / i;
            }
            
            MessageBox.Show($"O numero H sera: {H}");

        }

        private void lblN_Click(object sender, EventArgs e)
        {

        }

        private void frmExercicio2_Load(object sender, EventArgs e)
        {

        }
    }
}
