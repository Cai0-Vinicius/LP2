﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmExercicio3 : Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnVerif_Click(object sender, EventArgs e)
        {
            if (txtFrase.Text.Length > 50)
            {
                MessageBox.Show("frase maior que 50.");
                txtFrase.Focus();
            }
            else 
            { 
                string frase = txtFrase.Text;

                string NovaFrase = frase.Replace(" ", "").ToLower();
                string fraseReversa = new string(NovaFrase.Reverse().ToArray());
                
                if (NovaFrase == fraseReversa)
                {
                    MessageBox.Show("É um palíndromo");
                }
                else
                    MessageBox.Show("Não é um palíndromo");

            }
        
        }
    }
}
