﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade7
{
    public partial class frmExercicio4 : Form
    {
        double Salario, Prod, grat, SalBruto, B = 0, C = 0, D = 0;
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnVerifS_Click(object sender, EventArgs e)
        {
            double.TryParse(txtS.Text, out Salario);
            double.TryParse(txtP.Text, out Prod);
            double.TryParse(txtG.Text, out grat);
            
            
            if (Prod >= 150)
            {
                D = 1;
                C = 1;
                B = 1;
            }
            else if (Prod >= 120)
            {
                C = 1;
                B = 1;
            }
            else
                B = 1;

            SalBruto = Salario + Salario * (0.005 * B + 0.1 * C + 0.1 * D) + grat;

            if (Prod >= 150 && grat > 0)
            {
                MessageBox.Show($"O salario bruto sera: {SalBruto} reais.");
            }
            else if (SalBruto > 7000)
                MessageBox.Show("O salario bruto sera de 7000 reais");
            else
                MessageBox.Show($"o salario sera de: {SalBruto} reais.");
        }
    }
}