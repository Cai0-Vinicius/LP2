﻿namespace Pmatrizes
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEXE = new System.Windows.Forms.Button();
            this.lboxResult = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnEXE
            // 
            this.btnEXE.Location = new System.Drawing.Point(174, 301);
            this.btnEXE.Name = "btnEXE";
            this.btnEXE.Size = new System.Drawing.Size(453, 73);
            this.btnEXE.TabIndex = 0;
            this.btnEXE.Text = "Executar";
            this.btnEXE.UseVisualStyleBackColor = true;
            this.btnEXE.Click += new System.EventHandler(this.btnEXE_Click);
            // 
            // lboxResult
            // 
            this.lboxResult.FormattingEnabled = true;
            this.lboxResult.ItemHeight = 16;
            this.lboxResult.Location = new System.Drawing.Point(129, 43);
            this.lboxResult.Name = "lboxResult";
            this.lboxResult.Size = new System.Drawing.Size(563, 212);
            this.lboxResult.TabIndex = 1;
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lboxResult);
            this.Controls.Add(this.btnEXE);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnEXE;
        private System.Windows.Forms.ListBox lboxResult;
    }
}