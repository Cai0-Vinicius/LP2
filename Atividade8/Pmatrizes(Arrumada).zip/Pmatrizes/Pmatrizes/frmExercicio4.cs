﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnEXE_Click(object sender, EventArgs e)
        {
            string[] nomes = new string[10];
            string auxiliar = "";
            int[] tamanho = new int[10];

            for (int i = 0; i < 10; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i}º nome completo.");

                if (string.IsNullOrEmpty(auxiliar))
                {
                    MessageBox.Show("Entrada invalida.");
                    break;
                }
                if (double.TryParse(auxiliar, out _))
                {
                    MessageBox.Show("numeros nao sao invalidos.");
                    i--;
                    continue;
                }

                nomes[i] = auxiliar;
                tamanho[i] = auxiliar.Replace(" ", "").Length;

            }

            for (int i = 0; i < nomes.Length; i++)
            {
                {
                    if (!string.IsNullOrEmpty(nomes[i]))
                    {
                        lboxResult.Items.Add($"O nome:{nomes[i]} tem {tamanho[i]} caracteres");
                    }
                }
            }
       
        }
    }
}
