﻿namespace Pmatrizes
{
    partial class frmExercicio5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lboxResult = new System.Windows.Forms.ListBox();
            this.btnEXE = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lboxResult
            // 
            this.lboxResult.FormattingEnabled = true;
            this.lboxResult.ItemHeight = 16;
            this.lboxResult.Location = new System.Drawing.Point(119, 60);
            this.lboxResult.Name = "lboxResult";
            this.lboxResult.Size = new System.Drawing.Size(563, 212);
            this.lboxResult.TabIndex = 3;
            // 
            // btnEXE
            // 
            this.btnEXE.Location = new System.Drawing.Point(164, 318);
            this.btnEXE.Name = "btnEXE";
            this.btnEXE.Size = new System.Drawing.Size(453, 73);
            this.btnEXE.TabIndex = 2;
            this.btnEXE.Text = "Executar";
            this.btnEXE.UseVisualStyleBackColor = true;
            this.btnEXE.Click += new System.EventHandler(this.btnEXE_Click);
            // 
            // frmExercicio5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lboxResult);
            this.Controls.Add(this.btnEXE);
            this.Name = "frmExercicio5";
            this.Text = "frmExercicio5";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lboxResult;
        private System.Windows.Forms.Button btnEXE;
    }
}