﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pmatrizes
{
    public partial class frmExercicio5 : Form
    {
        public frmExercicio5()
        {
            InitializeComponent();
        }

        private void btnEXE_Click(object sender, EventArgs e)
        {
            
            string ra = "0030482413060";
            int ultimoDigito = int.Parse(ra.Last().ToString());
            int n = ultimoDigito == 0 ? 2 : ultimoDigito + 1;


            string[,] respostasAlunos = new string[n, 10];
            string[] gabarito = { "A", "E", "C", "D", "E", "A", "C", "A", "D", "B" };
            string auxiliar = "";

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    do
                    {
                        auxiliar = Interaction.InputBox($"Digite a resposta do aluno {i + 1} para a questão {j + 1}", "Respostas Alunos").ToUpper();

                        if (string.IsNullOrEmpty(auxiliar) || !"ABCDE".Contains(auxiliar))
                        {
                            MessageBox.Show("Entrada invalida. apenas respostas (A,B,C,D,E)."); 
                        }
                        else
                        {
                            respostasAlunos[i, j] = auxiliar;
                        }

                    } while (string.IsNullOrEmpty(auxiliar) || !"ABCDE".Contains(auxiliar));
                }
            }
            
            
            for (int i = 0; i < respostasAlunos.GetLength(0); i++)
            {
                lboxResult.Items.Add($"Aluno {i + 1}:");

                for (int j = 0; j < 10; j++)
                {
                    string respostaAluno = respostasAlunos[i, j];
                    string respostaCorreta = gabarito[j];
                    bool acertou = respostaAluno == respostaCorreta;
                    string resultado = acertou ? "acertou" : "errou";

                    lboxResult.Items.Add($"  Questão {j + 1}: {resultado}. (Correta: {respostaCorreta}, Escolheu: {respostaAluno})");
                }
                lboxResult.Items.Add("");

            }
        }
    }
}
