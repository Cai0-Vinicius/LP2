﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;


namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            
            for (int i = 0;i < vetor.Length; i++) 
            {
                auxiliar = Interaction.InputBox($"Digite o Numero {i+1}º", "entrada de dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("numero inválido ");
                    i--;
                }
                
                
                Array.Reverse(vetor);
                auxiliar = "";
                foreach (int x in vetor)
                {
                    auxiliar += x + "\n";
                }
                
            }
            MessageBox.Show(auxiliar);
        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList minhalista = new ArrayList() {"Ana", "André", "Débora", "Fatima", "Joao", "Janete", "Otávio", "Marcelo", "Pedro"};
            minhalista.Remove("Otávio");
            string auxiliar = "";
            foreach (string nomes in minhalista)
            {
                auxiliar += nomes + "\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[,] vetor = new double[20,3];
            string auxiliar = "";

            for (int i = 0; i < 20; i++)
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {j + 1}º do aluno {i+1}.", "entrada de dados");
                    
                    if (auxiliar == "")
                    {
                      
                    }
                    else if(!double.TryParse(auxiliar, out vetor[i, j]) || vetor[i, j] < 0 || vetor[i, j] > 10) 
                    {
                        MessageBox.Show("numero inválido ");
                        i--;
                    }
                
                }
        }

    
        private void btnEx4_Click(object sender, EventArgs e)
        {

        }

        private void btnEx5_Click(object sender, EventArgs e)
        {

        }
    }
}
